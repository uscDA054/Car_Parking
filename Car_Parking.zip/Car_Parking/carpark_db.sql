-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2020 at 06:04 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `carpark_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tb`
--

CREATE TABLE IF NOT EXISTS `admin_tb` (
  `adm_id` int(22) NOT NULL AUTO_INCREMENT,
  `adm_username` varchar(255) NOT NULL,
  `adm_password` varchar(255) NOT NULL,
  `adm_lastseen` datetime NOT NULL,
  PRIMARY KEY (`adm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin_tb`
--

INSERT INTO `admin_tb` (`adm_id`, `adm_username`, `adm_password`, `adm_lastseen`) VALUES
(1, 'Divyang', '12345', '2020-08-14 06:46:54'),
(2, 'Aditya', '12345', '2020-08-13 05:56:05'),
(3, 'Anil', '12345', '2020-09-01 02:04:12');

-- --------------------------------------------------------

--
-- Table structure for table `booking_tb`
--

CREATE TABLE IF NOT EXISTS `booking_tb` (
  `book_id` int(22) NOT NULL AUTO_INCREMENT,
  `book_userid` int(22) NOT NULL,
  `book_floorid` int(22) NOT NULL,
  `book_floorspot` varchar(255) NOT NULL,
  `book_rateid` int(22) NOT NULL,
  `book_vehiclenumber` varchar(255) NOT NULL,
  `book_todate` varchar(255) NOT NULL,
  `book_fromdate` varchar(255) NOT NULL,
  `book_totime` varchar(255) NOT NULL,
  `book_fromtime` varchar(255) NOT NULL,
  `book_timediff` varchar(255) NOT NULL,
  `book_totalprice` varchar(255) NOT NULL,
  `book_status` enum('Confirm','Complete') NOT NULL,
  `book_cdate` datetime NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `booking_tb`
--

INSERT INTO `booking_tb` (`book_id`, `book_userid`, `book_floorid`, `book_floorspot`, `book_rateid`, `book_vehiclenumber`, `book_todate`, `book_fromdate`, `book_totime`, `book_fromtime`, `book_timediff`, `book_totalprice`, `book_status`, `book_cdate`) VALUES
(4, 7, 10, '51', 12, '\r\n		GJ18-CC-8899', '2020-08-25', '2020-08-25', '16:06', '17:56', '0-1-1', '15', 'Confirm', '2020-08-22 04:38:56');

-- --------------------------------------------------------

--
-- Table structure for table `floor_tb`
--

CREATE TABLE IF NOT EXISTS `floor_tb` (
  `flr_id` int(22) NOT NULL AUTO_INCREMENT,
  `flr_name` varchar(255) NOT NULL,
  `flr_space` varchar(255) NOT NULL,
  `flr_forspace` varchar(255) NOT NULL,
  PRIMARY KEY (`flr_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `floor_tb`
--

INSERT INTO `floor_tb` (`flr_id`, `flr_name`, `flr_space`, `flr_forspace`) VALUES
(1, 'Floor-1', '1-30', 'Motorcycle'),
(9, 'Floor-1', '31-40', 'Small Car'),
(10, 'Floor-2', '41-80', 'Small Car'),
(11, 'Floor-3', '81-120', 'Small Car'),
(12, 'Floor-4', '121-160', 'Big Car'),
(13, 'Floor-5', '161-200', 'Big Car'),
(14, 'Floor-6', '201-240', 'Big Car'),
(15, 'Floor-7', '241-280', 'Big Car'),
(16, 'Floor-8', '281-320', 'Big Car'),
(17, 'Floor-9', '321-360', 'Big Car'),
(18, 'Floor-10', '361-400', 'Big Car');

-- --------------------------------------------------------

--
-- Table structure for table `rate_tb`
--

CREATE TABLE IF NOT EXISTS `rate_tb` (
  `rate_id` int(22) NOT NULL AUTO_INCREMENT,
  `rate_vehicletype` enum('Car','Motorcycle') NOT NULL,
  `rate_days` enum('Week Day','Weekend') NOT NULL,
  `rate_time` enum('Day','Hour') NOT NULL,
  `rate_rate` varchar(255) NOT NULL,
  PRIMARY KEY (`rate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `rate_tb`
--

INSERT INTO `rate_tb` (`rate_id`, `rate_vehicletype`, `rate_days`, `rate_time`, `rate_rate`) VALUES
(5, 'Motorcycle', 'Week Day', 'Day', '10'),
(8, 'Car', 'Weekend', 'Day', '10'),
(7, 'Car', 'Week Day', 'Day', '25'),
(9, 'Motorcycle', 'Weekend', 'Day', '5'),
(10, 'Car', 'Week Day', 'Hour', '20'),
(11, 'Motorcycle', 'Week Day', 'Hour', '20'),
(12, 'Car', 'Weekend', 'Hour', '10'),
(13, 'Motorcycle', 'Weekend', 'Hour', '10');

-- --------------------------------------------------------

--
-- Table structure for table `user_tb`
--

CREATE TABLE IF NOT EXISTS `user_tb` (
  `user_id` int(22) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_contact` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_postalcode` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_cdate` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user_tb`
--

INSERT INTO `user_tb` (`user_id`, `user_name`, `user_contact`, `user_email`, `user_postalcode`, `user_password`, `user_cdate`) VALUES
(7, 'Anil', '0123456789', 'anil@gmail.com', '382028', '12345', '2020-08-13 04:08:13');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
