
<?php
$con = new mysqli('localhost','root','','carpark_db');

?>